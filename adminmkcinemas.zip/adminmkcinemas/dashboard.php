<?php
include('config.php');
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogout.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Side Navigation Bar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #e0eafc, #cfdef3);
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            display: flex;
            height: 100vh;
        }
        h1{
            text-align:center;
            margin-top:0;
        }
        /* Side Navigation Bar */
        .sidenav {
            height: 97%;
            width: 260px;
            background-color: #222831;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 20px;
            box-shadow: 4px 0 15px rgba(0, 0, 0, 0.5);
        }

        .sidenav h3 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
            font-size: 28px;
            color: #ffd369;
        }

        .sidenav a {
            width: 100%;
            padding: 24px 0;
            text-align: center;
            text-decoration: none;
            color: #eeeeee;
            font-weight: 500;
            transition: background-color 0.3s, transform 0.2s;
        }

        .sidenav a:hover {
            background-color: #ffd369;
            color: #000000;
            transform: scale(1.05);
            border-radius: 6px;
        }

        .sidenav a i {
            margin-right: 10px;
        }

        /* Content Section */
        .content {
            flex-grow: 1;
            padding: 30px;
            background-color: #ffffff;
            position: relative;
        }

        /* MK-CINEMAS Branding Top Right */
        .branding {
            position: absolute;
            top: 20px;
            right: 30px;
            font-size: 24px;
            font-weight: bold;
            color: #222831;
            background-color: #ffd369;
            padding: 10px 20px;
            border-radius: 6px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 10;
        }
    </style>
</head>
<body>
    <?php 
        
        
    ?>

    <!-- Side Navigation Bar -->
    <div class="sidenav">
        <h3>MK-CINEMAS</h3>
        <a href="home.php"><i class="fas fa-home"></i> Home</a>
        <a href="addmovie.php"><i class="fas fa-film"></i> Add Movie</a>
        <a href="viewmovie.php"><i class="fas fa-eye"></i> View Movie</a>
        <a href="addshow.php"><i class="fas fa-plus"></i> Add Show</a>
        <a href="addshowscreen.php"><i class="fas fa-plus"></i> Add Show Time & Screen</a>
        <a href="viewbook.php"><i class="fas fa-book"></i> Today Booking</a>
        <a href="viewshow.php"><i class="fas fa-search"></i> View Show</a>
        <a href="viewusers.php"><i class="fas fa-users"></i> View Users</a>
        <a href="adminlogout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- Content Section -->
    <div class="content">
        <!-- Branding at the top right -->
        <div class="branding">MK-CINEMAS</div>
        <!-- Your content here -->
        <!-- <h1>Welcome to MK-CINEMAS Admin Panel</h1> -->
        <!-- <p>Use the navigation bar to manage movies, shows, and theater details.</p> -->
    <!-- </div> -->
</body>
</html>
