<?php 
include('config.php');
include('dashboard.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Theatre Details</title>
<style>
    body {
        font-family: 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
    }

    img {
        margin-top: 5%;
        width: 100%;
        height: 90%;

    }
</style>
</head>
<body>
<img src="mkhomes.webp" alt="Theater Interior">
</body>
</html>
