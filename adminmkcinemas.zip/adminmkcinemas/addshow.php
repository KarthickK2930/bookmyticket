<?php 
include('config.php');
include('dashboard.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Movie Booking</title>
<style>
    .container {
        background-color: #fff;
        padding: 20px 30px;
        /* border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); */
        width: 100%;
        max-width: 400px;
        margin-left: 25%;
    }

    h1 {
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 8px; /* Space between label and input */
        color: #333;
    }

    select,
    input[type="text"],
    input[type="number"],
    input[type="date"],
    input[type="file"] {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-sizing: border-box;
        font-size: 16px;
        margin-top: 5px; /* Space above input field */
    }

    select:focus,
    input:focus {
        outline: none;
        border-color: #4CAF50;
        box-shadow: 0 0 5px rgba(76, 175, 80, 0.5);
    }

    button[type="submit"] {
        background-color: #4CAF50;
        color: white;
        border: none;
        padding: 12px;
        width: 100%;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.3s ease-in-out;
        margin-top: 15px; /* Space above the button */
    }

    button[type="submit"]:hover {
        background-color: #45a049;
    }
</style>


<script>
    function submitForm() {
        document.getElementById("addShowForm").submit();
    }
</script>
</head>
<body>

<div class="container">
    <h1 align=center>ADD SHOWS</h1>
    <form id="addShowForm" action="" method="POST">
    <div class="form-group">
        <label for="movie">Select Movie:</label>
        <select name="movie" id="movie" required>
            <option value="">Select Movie</option>
            <?php
            
            $tid = $_SESSION['tid'];
            $movie = $conn->query("SELECT * FROM movie");
            while ($row = $movie->fetch_assoc()) {
                $selected = isset($_POST['movie']) && $_POST['movie'] == $row["movieid"] ? "selected" : "";
                echo "<option value='" . $row["movieid"] . "' $selected>" . $row["moviename"] . "</option>";
            }
            ?>
        </select>
        </div>
        <div class="form-group">
        <label for="screen">Select Screen:</label>
        <select name="screen" id="screen" required onchange="submitForm()">
            <option value="">Select Screen</option>
            <?php
            $selectedScreen = isset($_POST['screen']) ? $_POST['screen'] : '';
            $screen = $conn->query("SELECT * FROM screens");
            while ($row = $screen->fetch_assoc()) {
                $selected = ($selectedScreen == $row["screenid"]) ? "selected" : "";
                echo "<option value='" . $row["screenid"] . "' $selected>" . $row["screenname"] . "</option>";
            }
            ?>
        </select>
        </div>
        <div class="form-group">
        <label for="stime">Select Show Times:</label>
        <select name="stime[]" id="stime" multiple required>
            <?php
            if (!empty($selectedScreen)) {
                $showtime = $conn->query("SELECT * FROM showtime WHERE screenid='" . $_POST['screen'] . "'");
                if ($showtime->num_rows > 0) {
                    while ($row = $showtime->fetch_assoc()) {
                        echo "<option value='" . $row["showtimeid"] . "'>" . $row["showtime"] . "</option>";
                    }
                } else {
                    echo "<option value=''>No available showtimes</option>";
                }
            } else {
                echo "<option value=''>Select a screen first</option>";
            }
            ?>
        </select>
        </div>
        <div class="form-group">
        <label for="startdate">Start Date:</label>
        <input type="date" name="startdate" id="startdate" required>
        </div>
        <button type="submit" name="addshow" class="btn">Add Show</button>
    </form>
</div>

<?php
if (isset($_POST['addshow'])) {
    $movieid = $_POST['movie'];
    $screenid = $_POST['screen'];
    $showtimes = $_POST['stime'];
    $startdate = $_POST['startdate'];

    foreach($showtimes as $st) {
        $result = "INSERT INTO tshows (showtimeid, screenid, movieid, startdate, status, rstatus) 
                    VALUES ('$st', '$screenid', '$movieid', '$startdate', '1', '0')";
        if (!$conn->query($result)) {
            echo "Error: " . $result . "<br>" . $conn->error;
        } else {
            echo "<script>alert('Added successfully'); window.location='viewshow.php';</script>";
        }
    }
}
$conn->close();
?>

</body>
</html>
