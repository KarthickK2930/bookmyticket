<?php 
include('config.php');
include('dashboard.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Show Time</title>
    <style>
        .container {
            background-color: #fff;
            padding: 30px 40px; 
            margin-left:30%;
            margin-top:5%;
            width: 100%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }
        select,
        input[type="time"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
            font-weight: bold;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>ADD SHOW TIME</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="screenname">Screen Name:</label>
                <select id="screenname" name="screenname" required>
                    <?php
                    
                    $query = "SELECT screenname FROM screens";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['screenname'] . "'>" . $row['screenname'] . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="showtime">Show Time:</label>
                <input type="time" id="showtime" name="showtime" required>
            </div>
            <button type="submit" name="addshow">Add Show Time</button>
        </form>
    </div>

<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $screenname = $_POST['screenname'];
        $showtime = $_POST['showtime'];
        
        $checkScreen = "SELECT screenid FROM screens WHERE screenname='$screenname'";
        $result = $conn->query($checkScreen);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $screenid = $row['screenid'];
            
            $insertQuery = "INSERT INTO showtime (screenid, showtime) VALUES ('$screenid', '$showtime')";
            if ($conn->query($insertQuery) === TRUE) {
                echo "<script>alert('Show time added successfully'); window.location='addshowscreen.php';</script>";
            } else {
                echo "Error: " . $insertQuery . "<br>" . $conn->error;
            }
        } else {
            echo "<script>alert('Screen not found. Please enter a valid screen name.');</script>";
        }
    }

    $conn->close();
?>
</body>
</html>
