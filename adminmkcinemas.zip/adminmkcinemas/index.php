<?php
// Sample admin credentials for hardcoded validation
session_start();
// Database connection details
include('config.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    

    // Query to fetch admin credentials from the database
    $sql = "SELECT * FROM admin WHERE adminname = '$username'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $admin = mysqli_fetch_assoc($result);
        $adminid=$admin['id'];
        // Assuming the password is stored as plain text (not recommended)
        if ($password === $admin['adminpw']) {
            $_SESSION['adminid']=$adminid;
            echo "<script>alert('Login successful! Welcome to MK-CINEMAS Admin Panel.'); window.location='home.php';</script>";
            exit();
        } else {
            echo "<script>alert('Invalid password. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Invalid username. Please try again.');</script>";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MK-CINEMAS Admin Login</title>
    <style>
        body {
            display: flex;
            height: 100vh;
            justify-content: center;
            align-items: center;
            /* background-color: #1a1a1a; */
            color: #fff;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a1a, #3c3c3c); /* Sleek gradient from dark to light gray */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* Modern font style */
            color: #ffffff; /* White text for contrast */
            margin: 0;
            padding: 0;
        }

        .login-container {
            /* background-color: #282828; */
            margin-bottom:20%;
            padding: 40px;
            border-radius: 12px;
            /* box-shadow: 0 4px 15px rgba(0, 0, 0, 0.8); */
            text-align: center;
            width: 100%;
            /* max-width: 550px; */
        }
        h1 {
            color: #ffcc00;
            margin-bottom: 5px;
        }
        h2 {
            color: #ffcc00;
            margin-bottom: 20px;
            font-size: 1.2rem;
        }
        input[type="text"],
        input[type="password"] {
            width: 20%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #444;
            border-radius: 6px;
            background-color: #fff;
            color: #000;
        }
        button {
            background-color: #ffcc00;
            border: none;
            color: #000;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            width: 10%;
            font-weight: bold;
            margin-top: 20px;
        }
        button:hover {
            background-color: #e6b800;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>MK-CINEMAS</h1>
        <h2>Admin Login</h2>
        <form method="POST" action="#">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
