<?php 
include('config.php');
include('dashboard.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Available Shows</title>
    <style>
    h2 {
        text-align: center;
        margin-bottom: 30px;
        color: #333;
    }

    table.table {
        width: 100%;
        border-collapse: collapse;
        border-radius: 10px;
        overflow: hidden;
    }

    table.table thead {
        background-color: #343a40;
        color: white;
    }

    table.table th, table.table td {
        padding: 15px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
    }

    table.table tbody tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    table.table tbody tr:hover {
        background-color: #e9ecef;
    }

    .btn {
        padding: 8px 16px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: 500;
        font-size: 14px;
        transition: background-color 0.3s ease, color 0.3s ease;
        margin: 2px;
        display: inline-block;
    }

    .btn-warning {
        background-color: #ffc107;
        color: #212529;
        border: none;
    }

    .btn-warning:hover {
        background-color: #e0a800;
        color: white;
    }

    .btn-success {
        background-color: #28a745;
        color: white;
        border: none;
    }

    .btn-success:hover {
        background-color: #218838;
    }

    h3 {
        text-align: center;
        color: #777;
    }
    </style>
</head>
<body>
    <div class="container">
        <h2>AVAILABLE SHOWS</h2>
        <?php
        
        $showQuery = "SELECT * FROM tshows";

        $showResult = mysqli_query($conn, $showQuery);

        if (mysqli_num_rows($showResult)) {
        ?>
            <div class="table">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Sl.no</th>
                            <th>Screen</th>
                            <th>Show Time</th>
                            <th>Movie</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sl = 1;
                        while ($shows = mysqli_fetch_array($showResult)) {
                            $showtimeId = $shows['showtimeid'];
                            $movieId = $shows['movieid'];
                            $status = $shows['status'];

                            // Get showtime info
                            $showtimeQuery = mysqli_query($conn, "SELECT * FROM showtime WHERE showtimeid='$showtimeId'");
                            $showTime = mysqli_fetch_array($showtimeQuery);

                            // Get screen info
                            $screenId = $showTime['screenid'];
                            $screenQuery = mysqli_query($conn, "SELECT * FROM screens WHERE screenid='$screenId'");
                            $screen = mysqli_fetch_array($screenQuery);

                            // Get movie info
                            $movieQuery = mysqli_query($conn, "SELECT * FROM movie WHERE movieid='$movieId'");
                            $movie = mysqli_fetch_array($movieQuery);
                        ?>
                        <tr>
                            <td><?= $sl++; ?></td>
                            <td><?= $screen['screenname']; ?></td>
                            <td><?= date('h:i A', strtotime($showTime['showtime'])); ?></td>
                            <td><?= $movie['moviename']; ?></td>
                            <td><?= $status == '1' ? 'Running' : 'Stopped'; ?></td>
                            <td>
                                <a href="startstopshow.php?id=<?= $shows['showid']; ?>&action=start" class="btn btn-success">Start Show</a>
                                <a href="startstopshow.php?id=<?= $shows['showid']; ?>&action=stop" class="btn btn-warning">Stop Show</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        <?php } else { ?>
            <h3>No Shows Added</h3>
        <?php } ?>
    </div>
</body>
</html>
