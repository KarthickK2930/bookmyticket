<?php
    include('config.php');
    include('dashboard.php'); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Movies AED</title>
<style>
  table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    font-size: 16px;
    text-align: center;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  }

  th, td {
    padding: 12px 15px;
    border: 1px solid #ddd;
  }

  th {
    background-color: #4CAF50;
    color: white;
    font-weight: bold;
  }

  tr:nth-child(even) {
    background-color: #f9f9f9;
  }

  tr:nth-child(odd) {
    background-color: #fff;
  }

  tr:hover {
    background-color: #f1f1f1;
  }

  img {
    border-radius: 8px;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
  }

  button[type="submit"],button {
    padding: 8px 12px;
    font-size: 14px;
    color: white;
    background-color: #007BFF;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
  }

  button[type="submit"]:hover,button:hover {
    background-color: #0056b3;
  }

  .table-container {
    max-height: 500px; /* Set the height you desire */
    overflow-y: auto;
    border: 1px solid #ddd;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  }
</style>
</head>
<body>
<h1 align="center">MOVIE DETAILS</h1>
<button type="submit" onclick="window.location='addmovie.php'">Add Movies</button><br><br>

<div class="table-container">
<?php
   
    $moviedetails = $conn->query("SELECT * FROM movie");
    echo "<table>
    <tr>
    <th>S.NO</th>
    <th>NAME</th>
    <th>DURATION</th>
    <th>LANGUAGE</th>
    <th>YEAR</th>
    <th>POSTER</th>
    <th>TRAILER</th>
    <th>EDIT</th>
    <th>DELETE</th>
    </tr>";
    $sno=1;
    while($row=$moviedetails->fetch_assoc()) {
        
        echo "<tr>";
        // echo "<td>".$row['movieid']."</td>";
        echo "<td>".$sno++."</td>";
        echo "<td>".$row['moviename']."</td>";
        echo "<td>".$row['duration']."</td>";
        echo "<td>".$row['languages']."</td>";
        echo "<td>".$row['years']."</td>";
        echo "<td><img src='addmovieimg/" . $row['poster'] . "' width='100' height='150'></td>";
        echo "<td>".$row['trailer']."</td>";
        echo "<td><button type='submit' onclick='window.location=\"editmovie.php?movieid=" . $row['movieid'] . "\"'>Edit</button></td>";
        echo "<td><button type='button' onclick='confirmDelete(\"" . $row['movieid'] . "\")'>Delete</button></td>";
        echo "</tr>";
    }
    echo "</table>";
?>
</div>
<br><br>
<!-- <button type="submit" onclick="window.location='addmovie.php.html'">Back</button> -->
<script>
function confirmDelete(movieid) {
    if (confirm('Are you sure you want to delete this movie?')) {
        window.location.href = 'deletemovie.php?movieid=' + movieid;
    }
}
</script>

