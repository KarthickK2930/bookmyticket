<?php
include('config.php');
include('dashboard.php');


$selectedScreen = isset($_POST['screen']) ? $_POST['screen'] : '';
$selectedShow = isset($_POST['show']) ? $_POST['show'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Booking</title>
    <style>
        /* body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #e0eafc, #cfdef3);
            margin: 0;
            padding: 0;
        } */

        h1 {
            text-align: center;
            padding-top: 30px;
            color: #2c3e50;
        }

        /* .container {
            background-color: #fff;
            max-width: 700px;
            margin: 30px auto;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        } */

        label {
            font-weight: bold;
            margin-top: 15px;
            display: block;
            color: #333;
        }

        select {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            margin-bottom: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
            background-color: #f7f7f7;
            font-size: 15px;
        }

        button {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2c80b4;
        }

        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            font-size: 15px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #3498db;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .error-message {
            margin-top: 20px;
            padding: 12px;
            background-color: #ffe0e0;
            color: #c0392b;
            border: 1px solid #f5c6cb;
            text-align: center;
            border-radius: 10px;
        }

        .goback-button {
            margin: 20px auto;
            display: block;
            padding: 12px 25px;
            background-color: #555;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            cursor: pointer;
        }

        .goback-button:hover {
            background-color: #333;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>View Booking</h1>

    <form action="viewbook.php" method="post">
        <label for="screen">Select Screen:</label>
        <select name="screen" id="screen" required onchange="this.form.submit()">
            <option value="">Select Screen</option>
            <?php
            $screenQuery = mysqli_query($conn, "SELECT * FROM screens");
            while ($row = mysqli_fetch_assoc($screenQuery)) {
                $isSelected = ($selectedScreen == $row['screenid']) ? 'selected' : '';
                echo "<option value='" . $row["screenid"] . "' $isSelected>" . $row["screenname"] . "</option>";
            }
            ?>
        </select>

        <label for="show">Select Show:</label>
        <select name="show" id="show" required>
            <option value="">Select Show</option>
            <?php
            if ($selectedScreen) {
                $showQuery = mysqli_query($conn, "SELECT * FROM showtime WHERE screenid='$selectedScreen'");
                while ($show = mysqli_fetch_assoc($showQuery)) {
                    $isSelected = ($selectedShow == $show['showtime']) ? 'selected' : '';
                    echo "<option value='" . $show['showtime'] . "' $isSelected>" . $show['showtime'] . "</option>";
                }
            }
            ?>
        </select>

        <button type="submit">View Booking</button>
    </form>

    <?php
    if (!empty($selectedScreen) && !empty($selectedShow)) {
        $result1 = $conn->query("SELECT * FROM showtime WHERE screenid='$selectedScreen' AND showtime='$selectedShow'");
        if ($result1->num_rows > 0) {
            $row = $result1->fetch_assoc();
            $stid = $row['showtimeid'];

            $result2 = $conn->query("SELECT * FROM tshows WHERE showtimeid='$stid'");
            if ($result2->num_rows > 0) {
                $row = $result2->fetch_assoc();
                $showid = $row['showid'];

                $t = $conn->query("SELECT * FROM tickets WHERE showid='$showid' AND ticketdate=CURDATE()");
                if ($t->num_rows > 0) {
                    echo "<table>";
                    echo "<tr><th>Ticket ID</th><th>Name</th><th>BMT ID</th><th>No. of Tickets</th><th>Booking Seats</th></tr>";
                    while ($ticket = $t->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $ticket['ticketid'] . "</td>";
                        echo "<td>" . $ticket['name'] . "</td>";
                        echo "<td>" . $ticket['bmtid'] . "</td>";
                        echo "<td>" . $ticket['notickets'] . "</td>";
                        echo "<td>" . $ticket['seats'] . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<div class='error-message'>No tickets found for the selected show.</div>";
                }
            } else {
                echo "<div class='error-message'>No shows found for the selected showtime.</div>";
            }
        } else {
            echo "<div class='error-message'>No showtime found for the selected time.</div>";
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        echo "<div class='error-message'>Please select both screen and show.</div>";
    }
    ?>

    <button class="goback-button" onclick="history.go(-1)">Go Back</button>
</div>

</body>
</html>
<?php
mysqli_close($conn);
?>
