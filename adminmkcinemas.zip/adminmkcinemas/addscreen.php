<?php 
include('config.php');
include('dashboard.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Movies</title>
    <style>
        /* body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        } */
        .container {
            background-color: #fff;
            padding: 30px 40px;
            /* border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1); */
            width: 100%;
            margin-left:30%;
            margin-top:5%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }
        input[type="text"],
        input[type="number"],
        input[type="url"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
            font-weight: bold;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>ADD SCREENS</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="screenname">Screen Name:</label>
                <input type="text" id="screenname" name="screenname" required>
            </div>
            <div class="form-group">
                <label for="seats">Seats:</label>
                <input type="text" id="seats" name="seats" required>
            </div>
            <div class="form-group">
                <label for="charge">Price:</label>
                <input type="text" id="charge" name="price" required>
            </div>
            <button type="submit" name="as">Add</button>
        </form>
    </div>

<?php
    

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $screenname = $_POST['screenname'];
        $seats = $_POST['seats'];
        $price = $_POST['price'];
        
        $result = "INSERT INTO screens (screenname,seats,price) VALUES ('$screenname', '$seats', '$price')";
        
        if ($conn->query($result) == true) {
            echo "<script>alert('Added successfully'); window.location='addshowscreen.php';</script>";
        } else {
            echo "Error: " . $result . "<br>" . $conn->error;
        }
    }

    $conn->close();
?>
</body>
</html>
