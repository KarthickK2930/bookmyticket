<?php 

include('config.php');
include('dashboard.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Screens & Showtimes</title>
<style>
    body {
        font-family: 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
    }
    .container2 {
        max-width: 1000px;
        padding: 30px;
        margin-right: 20px;
        margin-top: 5%;
        background-color: #fff;
        border-radius: 8px;
    }
    /* .scroll-section2 {
        max-height: 300px;
        overflow-y: auto;
        border: 2px solid #007bff;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
    } */
    table {
        width: 90%;
        margin-top:2%;
        margin-left:3%;
        border-collapse: collapse;
    }
    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #007bff;
        color: #fff;
        position: sticky;
        top: 0;
    }
    .add-screen-button{
        width: 20%;
        margin-left: 3%;
        padding: 10px;
        background-color: black;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        margin-top: 5%;
    }
    .add-showtime-button {
        width: 100%;
        margin-left: 3%;
        padding: 10px;
        background-color: black;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        margin-top: 5%;
    }
    .add-screen-button:hover,
    .add-showtime-button:hover {
        background-color: #ff0000;
    }
</style>
</head>
<body>
<div class="container">
    <button class="add-screen-button" type="button" onclick="window.location='addscreen.php'">Add Screen</button>
    
    <div class="scroll-section">
        <table>
            <tr>
                <th>Screen Details</th>
            </tr>
            <tr></tr>
            <tr>
                <th>Serial No</th>
                <th>Screen Name</th>
                <th>Seats</th>
                <th>Charge</th>
                <th>Show Time</th>
                <th>Action</th>
            </tr>
            <?php
            

            $sdetails = $conn->query("SELECT * FROM screens");
            $s = 1;
            while ($row = $sdetails->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $s . "</td>";
                echo "<td>" . $row['screenname'] . "</td>";
                echo "<td>" . $row['seats'] . "</td>";
                echo "<td>" . $row['price'] . "</td>";
            ?>
                <td>
                    <?php
                    $st = $conn->query("SELECT * FROM showtime WHERE screenid='" . $row['screenid'] . "'");
                    if (mysqli_num_rows($st)) {
                        while ($stm = mysqli_fetch_array($st)) {
                            echo date('h:i a', strtotime($stm['showtime'])) . " ,";
                        }
                    } else {
                        echo "No Show Time Added";
                    }
                    ?>
                </td>
                <td>
                    <button class='add-showtime-button' type='button' 
                    onclick="window.location='addshowtime.php?screenid=<?php echo $row['screenid']; ?>'">
                    Add Showtime</button>
                </td>
                <?php
                echo "</tr>";
                $s++;
            }
            ?>
        </table>
    </div>
</div>
</body>
</html>
