<?php
include('config.php');
include('dashboard.php'); 


if (isset($_GET['movieid'])) {
    $movieid = $_GET['movieid'];
    $sql = "DELETE FROM movie WHERE movieid='$movieid'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Movie deleted successfully!'); window.location='viewmovie.php';</script>";
    } else {
        echo "<p>Error deleting movie: " . mysqli_error($conn) . "</p>";
    }
}
?>
