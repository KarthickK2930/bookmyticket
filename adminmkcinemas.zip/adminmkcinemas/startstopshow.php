<?php
include('config.php');
include('dashboard.php'); // Adjust path if needed

if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];
    $currentDate = date('Y-m-d'); // Get today's date

    if ($action === 'start') {
        // Start today's show with this ID
        $update = "UPDATE tshows SET status='1' WHERE showid='$id' AND startdate='$currentDate'";
    } elseif ($action === 'stop') {
        // Stop today's show with this ID without affecting future dates
        $update = "UPDATE tshows SET status='0' WHERE showid='$id' AND startdate='$currentDate'";
    }

    if (isset($update)) {
        mysqli_query($conn, $update);
    }
}

header("Location: viewshow.php");
exit();
?>