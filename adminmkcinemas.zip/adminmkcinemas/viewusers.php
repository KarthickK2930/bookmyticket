<?php
include('config.php');
include('dashboard.php');


$users = $conn->query("SELECT * FROM users");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Users</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* .container {
            max-width: 1100px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        } */

        h1 {
            color: #e50914;
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        th, td {
            padding: 16px;
            text-align: center;
            font-size: 16px;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #e50914;
            color: #fff;
            font-weight: 600;
        }

        td {
            background-color: #fafafa;
            color: #333;
        }

        tr:hover td {
            background-color: #f1f1f1;
        }

        @media (max-width: 768px) {
            table, th, td {
                font-size: 14px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>USER DETAILS</h1>
    <?php
    if ($users->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>S.NO</th><th>BMT ID</th><th>FIRST NAME</th><th>LAST NAME</th><th>USERNAME</th><th>PASSWORD</th>
        <th>MOBILE NO</th><th>EMAIL</th></tr>";
        $sno = 1;
        while ($row = $users->fetch_assoc()) {
            echo "<tr>";
            echo "<td>$sno</td>";
            echo "<td>{$row['id']}</td>";
            echo "<td>{$row['fname']}</td>";
            echo "<td>{$row['lname']}</td>";
            echo "<td>{$row['username']}</td>";
            echo "<td>{$row['pw']}</td>";
            echo "<td>{$row['mobile']}</td>";
            echo "<td>{$row['email']}</td>";
            echo "</tr>";
            $sno++;
        }
        echo "</table>";
    } else {
        echo "<p style='text-align:center; font-size:18px; color:#888;'>No users found.</p>";
    }
    ?>
</div>

</body>
</html>
