<?php 
include('config.php'); 

include('dashboard.php'); 

// Database connection



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $movie_name = $_POST['movie_name'];
    $duration = $_POST['duration'];
    $language = $_POST['language'];
    $year = $_POST['year'];
    $poster = $_FILES['poster']['name'];
    $trailer = $_POST['trailer'];
    
    $target_file = "addmovieimg/" . basename($_FILES["poster"]["name"]);

    if (move_uploaded_file($_FILES['poster']['tmp_name'], $target_file)) {
        $sql = "INSERT INTO movie (moviename, duration, languages, years, poster, trailer)
                VALUES ('$movie_name', '$duration', '$language', '$year', '$poster', '$trailer')";

        if ($conn->query($sql) === true) {
            echo "<script>alert('Movie added successfully'); window.location='viewmovie.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "<script>alert('Failed to move uploaded poster file');</script>";
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Movies</title>
    <style>
        /* body {
            display: flex;
            height: 100vh;
            justify-content: center;
            align-items: center;
            background-color: #f0f2f5;
        } */
        .container {
            /* background-color: #fff; */
            padding: 20px 30px;
            border-radius: 12px;
            /* box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); */
            width: 100%;
            max-width: 400px;
            margin-left:25%;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"],
        input[type="url"],
        input[type="file"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        .btn-submit {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            width: 100%;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn-submit:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>ADD MOVIES</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="movie_name">Movie Name</label>
                <input type="text" id="movie_name" name="movie_name" required>
            </div>
            <div class="form-group">
                <label for="duration">Duration (in minutes)</label>
                <input type="number" id="duration" name="duration" required>
            </div>
            <div class="form-group">
                <label for="language">Language</label>
                <input type="text" id="language" name="language" required>
            </div>
            <div class="form-group">
                <label for="year">Year</label>
                <input type="number" id="year" name="year" required>
            </div>
            <div class="form-group">
                <label for="poster">Movie Poster</label>
                <input type="file" id="poster" name="poster" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="trailer">Trailer URL</label>
                <input type="url" id="trailer" name="trailer" required>
            </div>
            <button type="submit" class="btn-submit">Add Movie</button>
        </form>
    </div>
</body>
</html>
