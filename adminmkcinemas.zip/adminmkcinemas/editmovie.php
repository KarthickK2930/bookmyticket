<?php
include('config.php');
include('dashboard.php'); 


if(isset($_GET['movieid'])){
    $movieid = $_GET['movieid'];
    $sql = "SELECT * FROM movie WHERE movieid='$movieid'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $movie = $result->fetch_assoc();
    } else {
        echo "<p>No Movie found with ID $movieid</p>";
        exit();
    }
} else {
    echo "<p>No ID provided</p>";
    exit();
}

if (isset($_POST['update'])) {
    $movieid = $_POST['movieid'];
    $moviename = $_POST['moviename'];
    $duration = $_POST['duration'];
    $languages = $_POST['languages'];
    $years = $_POST['years'];
    $trailer = $_POST['trailer'];

    // Handle poster upload
    $poster = $movie['poster']; // Keep existing poster if not changed
    if (!empty($_FILES['poster']['name'])) {
        $target_dir = "addmovieimg/";
        $poster = $target_dir . basename($_FILES["poster"]["name"]);
        move_uploaded_file($_FILES["poster"]["tmp_name"], $poster);
    }

    $sql = "UPDATE movie 
            SET moviename='$moviename', duration='$duration', 
                languages='$languages', years='$years', 
                poster='$poster', trailer='$trailer'
            WHERE movieid='$movieid'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Movie updated successfully!'); window.location='viewmovie.php';</script>";
    } else {
        echo "Error updating movie: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Movie</title>
<style>
    /* body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        display: flex;
        height: 100vh;
        align-items: center;
        justify-content: center;
    } */
    .container {
        background-color: #fff;
        padding: 20px 30px;
        border-radius: 12px;
        width: 100%;
        max-width: 400px;
        margin-left:25%;
        /* box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); */
    }
    h1 {
        text-align: center;
        color: #4CAF50;
        margin-bottom: 20px;
    }
    label {
        display: block;
        margin-top: 10px;
        font-weight: bold;
    }
    input[type="text"],
    input[type="number"],
    input[type="url"],
    input[type="file"] {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 6px;
        margin-bottom: 10px;
    }
    .btn-submit,button {
        background-color: #4CAF50;
        color: #fff;
        margin-left:25%;
        border: none;
        padding: 10px 20px;
        width: 50%;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .btn-submit:hover,button:hover {
        background-color: #45a049;
    }
   
</style>
</head>
<body>
<div class="container">
<h1>EDIT MOVIES</h1>

<?php if ($movie): ?>
<form method="post" action="" enctype="multipart/form-data">
    <input type="hidden" name="movieid" value="<?php echo $movie['movieid']; ?>">

    <label for="moviename">Name:</label>
    <input type="text" id="moviename" name="moviename" value="<?php echo htmlspecialchars($movie['moviename']); ?>" required>

    <label for="duration">Duration:</label>
    <input type="text" id="duration" name="duration" value="<?php echo htmlspecialchars($movie['duration']); ?>" required>

    <label for="languages">Language:</label>
    <input type="text" id="languages" name="languages" value="<?php echo htmlspecialchars($movie['languages']); ?>" required>

    <label for="years">Year:</label>
    <input type="text" id="years" name="years" value="<?php echo htmlspecialchars($movie['years']); ?>" required>

    <label for="poster">Poster:</label>
    <input type="file" id="poster" name="poster" accept="image/*">

    <label for="trailer">Trailer (YouTube/Video URL):</label>
    <input type="url" id="trailer" name="trailer" value="<?php echo htmlspecialchars($movie['trailer']); ?>" required>

    <button class="btn-submit" type="submit" name="update">Update</button>
</form>

<?php else: ?>
<p>No movie selected to edit. Please go back and try again.</p>
<?php endif; ?>
<br>
<button type="submit" onclick="window.location='viewmovie.php'">Go Back</button><br><br>
</div>
</body>
</html>
